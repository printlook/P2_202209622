import os
import requests
import datetime as dt
import xml.etree.ElementTree as ET
import re
import base64
import matplotlib.pyplot as plt
from io import BytesIO
from fpdf import FPDF
from django.conf import settings
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.urls import path

DIRECTORIO_BASE = os.path.dirname(os.path.abspath(__file__))
RUTA_RESPUESTA = os.path.join(DIRECTORIO_BASE, 'archivos', 'salida.xml')
PALABRAS_POSITIVAS = ["bien", "feliz", "alegre", "contento", "bueno", "excelente", "satisfecho"]
PALABRAS_NEGATIVAS = ["enojado", "molesto", "malo", "pésimo", "triste", "decepcionado"]

settings.configure(
    DEBUG=True,
    SECRET_KEY='clave-secreta-para-django',
    ROOT_URLCONF=__name__,
    ALLOWED_HOSTS=['*'],
    MIDDLEWARE=[
        'django.middleware.common.CommonMiddleware',
        'django.middleware.csrf.CsrfViewMiddleware',
        'django.middleware.clickjacking.XFrameOptionsMiddleware',
    ],
    TEMPLATES=[{
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(DIRECTORIO_BASE, 'Templates')],
        'APP_DIRS': True,
    }],
    STATIC_URL='/static/',
    STATICFILES_DIRS = [os.path.join(DIRECTORIO_BASE, 'static')],
    
    INSTALLED_APPS=[
        'django.contrib.staticfiles',
    ],
    SESSION_ENGINE='django.contrib.sessions.backends.file',
    SESSION_FILE_PATH=os.path.join(DIRECTORIO_BASE, 'sessions'),
)

# Vistas
def vista_principal(solicitud):
    return render(solicitud, 'index.html', {'mostrar_ayuda': False})

def procesar_entrada(solicitud):
    if solicitud.method == 'POST' and 'archivo' in solicitud.FILES:
        archivo = solicitud.FILES['archivo']
        contenido_entrada = archivo.read().decode('utf-8')

        try:
            archivo.seek(0)
            respuesta = requests.post(
                'http://127.0.0.1:5000/cargar_archivo',
                files={'archivo': archivo}
            )
            respuesta.raise_for_status()
            contenido = respuesta.json().get('contenido_archivo', 'Error al procesar el archivo')
        except requests.RequestException as e:
            contenido = f'Error al conectar con el backend: {str(e)}'

        return render(solicitud, 'index.html', {
            'resultado': contenido,  
            'contenido_archivo': contenido_entrada,
            'mostrar_ayuda': False
        })
    return redirect('index')

def reiniciar_datos(solicitud):
    if solicitud.method == 'POST':
        mensaje = "Datos reiniciados exitosamente."
        return render(solicitud, 'index.html', {'mensaje': mensaje})
    return redirect('index')

def cargar_archivo(solicitud):
    if solicitud.method == 'POST' and solicitud.FILES['archivo']:
        archivo = solicitud.FILES['archivo']
        respuesta = requests.post('http://127.0.0.1:5000/cargar_archivo', files={'archivo': archivo})
        contenido_archivo = respuesta.json().get('contenido_archivo', 'Error al cargar el archivo')
        return render(solicitud, 'index.html', {'contenido_archivo': contenido_archivo})
    return redirect('index')

def mostrar_peticiones(solicitud):
    return render(solicitud, 'peticiones.html')

def consultar_datos(solicitud):
    if solicitud.method == 'POST':
        if os.path.exists(RUTA_RESPUESTA):
            with open(RUTA_RESPUESTA, 'r', encoding='utf-8') as archivo:
                contenido = archivo.read()
        else:
            contenido = "No se encontró ningún archivo de respuesta."
        return render(solicitud, 'peticiones.html', {'contenido_respuesta': contenido})
    return redirect('peticiones')

def por_fecha(solicitud):
    if solicitud.method == "POST":
        fecha_seleccionada = solicitud.POST.get("fecha")
        fecha_seleccionada = dt.datetime.strptime(fecha_seleccionada, "%Y-%m-%d").strftime("%d/%m/%Y")
        
        try:
            arbol = ET.parse("archivos/salida.xml")
            raiz = arbol.getroot()
            total_mensajes, total_positivos, total_negativos, total_neutros = 0, 0, 0, 0
            
            for respuesta in raiz.findall("respuesta"):
                fecha_xml = respuesta.find("fecha").text.strip()
                if fecha_xml == fecha_seleccionada:
                    mensajes = respuesta.find("mensajes")
                    total_mensajes += int(mensajes.find("total").text or 0)
                    total_positivos += int(mensajes.find("positivos").text or 0)
                    total_negativos += int(mensajes.find("negativos").text or 0)
                    total_neutros += int(mensajes.find("neutros").text or 0)

            if total_mensajes == 0:
                return render(solicitud, "peticiones.html", {
                    "mensaje": "No hay mensajes registrados para la fecha seleccionada."
                })

            tamano = [total_positivos, total_negativos, total_neutros]
            etiquetas = ["Positivos", "Negativos", "Neutros"]
            colores = ["#66c2a5", "#fc8d62", "#8da0cb"]

            if sum(tamano) == 0:
                return render(solicitud, "peticiones.html", {
                    "mensaje": "No se pueden generar gráficos porque todos los valores son cero."
                })

            plt.figure(figsize=(6, 6))
            plt.pie(tamano, labels=etiquetas, autopct="%1.1f%%", colors=colores, startangle=140)
            plt.axis("equal")

            buffer = BytesIO()
            plt.savefig(buffer, format="png")
            plt.close()
            buffer.seek(0)
            imagen_png = buffer.getvalue()
            buffer.close()
            grafica = base64.b64encode(imagen_png).decode("utf-8")

            return render(solicitud, "peticiones.html", {"grafica": grafica})
        except ET.ParseError as e:
            return render(solicitud, "peticiones.html", {
                "mensaje": f"Error al leer el archivo XML: {str(e)}"
            })
    return render(solicitud, "peticiones.html")

def generar_reporte_pdf(solicitud):
    archivo_xml = os.path.join(DIRECTORIO_BASE, 'archivos', 'salida.xml')
    if not os.path.exists(archivo_xml):
        return HttpResponse("El archivo XML de respuesta no existe.")

    arbol = ET.parse(archivo_xml)
    raiz = arbol.getroot()
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 10, "Reporte de Peticiones", 0, 1, 'C')
    pdf.set_font("Arial", "", 10)

    for respuesta in raiz.findall("respuesta"):
        fecha = respuesta.find("fecha").text
        total_msgs = respuesta.find("mensajes/total").text
        pos_msgs = respuesta.find("mensajes/positivos").text
        neg_msgs = respuesta.find("mensajes/negativos").text
        neut_msgs = respuesta.find("mensajes/neutros").text
        pdf.cell(0, 10, f"Fecha: {fecha}", 0, 1)
        pdf.cell(0, 10, f"Total Mensajes: {total_msgs}, Positivos: {pos_msgs}, Negativos: {neg_msgs}, Neutros: {neut_msgs}", 0, 1)
        
        for empresa in respuesta.findall("analisis/empresa"):
            nombre_empresa = empresa.get("nombre")
            pdf.cell(0, 10, f"  Empresa: {nombre_empresa}", 0, 1)
            emp_total = empresa.find("mensajes/total").text
            emp_pos = empresa.find("mensajes/positivos").text
            emp_neg = empresa.find("mensajes/negativos").text
            emp_neut = empresa.find("mensajes/neutros").text
            pdf.cell(0, 10, f"    Total: {emp_total}, Positivos: {emp_pos}, Negativos: {emp_neg}, Neutros: {emp_neut}", 0, 1)

            for servicio in empresa.findall("servicios/servicio"):
                nombre_servicio = servicio.get("nombre")
                serv_total = servicio.find("mensajes/total").text
                serv_pos = servicio.find("mensajes/positivos").text
                serv_neg = servicio.find("mensajes/negativos").text
                serv_neut = servicio.find("mensajes/neutros").text
                pdf.cell(0, 10, f"      Servicio: {nombre_servicio}", 0, 1)
                pdf.cell(0, 10, f"        Total: {serv_total}, Positivos: {serv_pos}, Negativos: {serv_neg}, Neutros: {serv_neut}", 0, 1)

    response = HttpResponse(content_type="application/pdf")
    response["Content-Disposition"] = "attachment; filename=reporte.pdf"
    pdf.output(response, "F")
    return response

def por_rango(request):
    if request.method == 'POST':
        fecha_inicio = request.POST.get('fecha_inicio')
        fecha_fin = request.POST.get('fecha_fin')
        empresa = request.POST.get('empresa', '').strip()

        try:
            params = {'fecha_inicio': fecha_inicio, 'fecha_fin': fecha_fin}
            if empresa:
                params['empresa'] = empresa
            response = requests.get('http://127.0.0.1:5000/rango_resumen', params=params)
            response.raise_for_status()
            datos = response.json()

            fechas = [item['fecha'] for item in datos]
            total = [item['total'] for item in datos]
            positivos = [item['positivos'] for item in datos]
            negativos = [item['negativos'] for item in datos]
            neutros = [item['neutros'] for item in datos]

            fig, ax = plt.subplots()
            ax.plot(fechas, total, label='Total', color='blue')
            ax.plot(fechas, positivos, label='Positivos', color='green')
            ax.plot(fechas, negativos, label='Negativos', color='red')
            ax.plot(fechas, neutros, label='Neutros', color='gray')
            
            ax.set_title(f'Resumen de mensajes por rango de fechas - {empresa or "Todas las empresas"}')
            ax.set_xlabel('Fecha')
            ax.set_ylabel('Cantidad de mensajes')
            ax.legend()

            buffer = BytesIO()
            fig.savefig(buffer, format='png')
            buffer.seek(0)
            imagen_base64 = base64.b64encode(buffer.read()).decode('utf-8')
            buffer.close()

            return render(request, 'peticiones.html', {
                'grafica_rango': imagen_base64,
                'contenido_respuesta': datos,
            })
        except requests.RequestException as e:
            return render(request, 'peticiones.html', {
                'mensaje': f'Error al conectar con el backend: {str(e)}',
            })
    return redirect('peticiones')

def prueba_mensaje(request):
    if request.method == 'POST':
        mensaje_xml = request.POST.get('mensaje_xml')
        
        try:
            mensaje = ET.fromstring(mensaje_xml)
            contenido_mensaje = mensaje.text.strip()
            
            fecha_match = re.search(r'(\d{2}/\d{2}/\d{4})', contenido_mensaje)
            red_social_match = re.search(r'Red social: (\w+)', contenido_mensaje)
            usuario_match = re.search(r'Usuario: ([\w\.-]+@[\w\.-]+)', contenido_mensaje)

            fecha = fecha_match.group(1) if fecha_match else "Fecha no encontrada"
            red_social = red_social_match.group(1) if red_social_match else "Red social no encontrada"
            usuario = usuario_match.group(1) if usuario_match else "Usuario no encontrado"

            palabras_positivas = sum(word in contenido_mensaje.lower() for word in PALABRAS_POSITIVAS)
            palabras_negativas = sum(word in contenido_mensaje.lower() for word in PALABRAS_NEGATIVAS)
            
            total_palabras = palabras_positivas + palabras_negativas
            if total_palabras > 0:
                sentimiento_positivo = f"{(palabras_positivas / total_palabras) * 100:.2f}%"
                sentimiento_negativo = f"{(palabras_negativas / total_palabras) * 100:.2f}%"
                sentimiento_analizado = "positivo" if palabras_positivas > palabras_negativas else "negativo"
            else:
                sentimiento_positivo = "0%"
                sentimiento_negativo = "0%"
                sentimiento_analizado = "neutro"

            respuesta = f"""
            <respuesta>
                <fecha>{fecha}</fecha>
                <red_social>{red_social}</red_social>
                <usuario>{usuario}</usuario>
                <empresas>
                    <empresa nombre="USAC">
                        <servicio>inscripción</servicio>
                    </empresa>
                </empresas>
                <palabras_positivas>{palabras_positivas}</palabras_positivas>
                <palabras_negativas>{palabras_negativas}</palabras_negativas>
                <sentimiento_positivo>{sentimiento_positivo}</sentimiento_positivo>
                <sentimiento_negativo>{sentimiento_negativo}</sentimiento_negativo>
                <sentimiento_analizado>{sentimiento_analizado}</sentimiento_analizado>
            </respuesta>
            """

            return render(request, 'peticiones.html', {
                'resultado_prueba': respuesta.strip(),
            })

        except ET.ParseError as e:
            return render(request, 'peticiones.html', {
                'resultado_prueba': f"Error al analizar el mensaje XML: {str(e)}"
            })
    
    return redirect('peticiones')

def mostrar_ayuda(request):
    return render(request, 'ayuda.html') 

urlpatterns = [
    path('', vista_principal, name='index'),
    path('procesar_entrada/', procesar_entrada, name='procesar_entrada'),
    path('consultar/', consultar_datos, name='consultar_datos'),
    path('fecha/', por_fecha, name='por_fecha'),
    path('reiniciar_datos/', reiniciar_datos, name='reiniciar_datos'),
    path('pdf/', generar_reporte_pdf, name='generar_reporte_pdf'),
    path('peticiones/', mostrar_peticiones, name='peticiones'),
    path('rango/', por_rango, name='rango_resumen'),
    path('ayuda/', mostrar_ayuda, name='ayuda'),
    path('prueba/', prueba_mensaje, name='prueba')
]

if __name__ == '__main__':
    from django.core.management import execute_from_command_line
    execute_from_command_line(['manage.py', 'runserver'])