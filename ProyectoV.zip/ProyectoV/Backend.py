from flask import Flask, request, jsonify
import os
import xml.etree.ElementTree as XML
import unidecode
from xml.dom import minidom
import re

aplicacion = Flask(__name__)

class AnalisisSentimiento:
    def __init__(self):
        self.total_mensajes = 0
        self.positivos_mensajes = 0
        self.negativos_mensajes = 0
        self.neutros_mensajes = 0

    def aumentar_sentimiento(self, tipo_sentimiento):
        self.total_mensajes += 1
        if tipo_sentimiento == 'positivo':
            self.positivos_mensajes += 1
        elif tipo_sentimiento == 'negativo':
            self.negativos_mensajes += 1
        elif tipo_sentimiento == 'neutro':
            self.neutros_mensajes += 1

class AnalisisEmpresa:
    def __init__(self, nombre_empresa):
        self.nombre_empresa = nombre_empresa
        self.analisis_general = AnalisisSentimiento()
        self.servicios_empresa = {}

    def agregar_servicio(self, nombre_servicio):
        if nombre_servicio not in self.servicios_empresa:
            self.servicios_empresa[nombre_servicio] = AnalisisSentimiento()

    def aumentar_servicio(self, nombre_servicio, tipo_sentimiento):
        self.agregar_servicio(nombre_servicio)
        self.servicios_empresa[nombre_servicio].aumentar_sentimiento(tipo_sentimiento)

def normalizar_texto(texto):
    return unidecode.unidecode(texto.lower())

analisis_por_fecha = {}

@aplicacion.route('/cargar_archivo', methods=['POST'])
def cargar_archivo():
    if 'archivo' in request.files:
        archivo = request.files['archivo']
        ruta_archivo = os.path.join('archivos', archivo.filename)
        archivo.save(ruta_archivo)

        with open(ruta_archivo, 'r', encoding='utf-8') as archivo_abierto:
            contenido = archivo_abierto.read()
    elif 'contenido' in request.form:
        contenido = request.form['contenido']
    else:
        return jsonify({'error': 'No se envió un archivo ni contenido de texto'}), 400

    try:
        xml_arbol = XML.ElementTree(XML.fromstring(contenido))
        xml_raiz = xml_arbol.getroot()

        nodo_diccionario = xml_raiz.find('diccionario')
        if nodo_diccionario is None:
            raise ValueError("El diccionario no se encuentra en el archivo XML")

        nodo_positivos = nodo_diccionario.find('sentimientos_positivos')
        nodo_negativos = nodo_diccionario.find('sentimientos_negativos')

        if nodo_positivos is None or nodo_negativos is None:
            raise ValueError("No se encontraron los nodos de sentimientos en el diccionario")

        palabras_positivas = {normalizar_texto(palabra.text.strip()) for palabra in nodo_positivos.findall('palabra')}
        palabras_negativas = {normalizar_texto(palabra.text.strip()) for palabra in nodo_negativos.findall('palabra')}

        nodo_empresas = nodo_diccionario.find('empresas_analizar')

        total_mensajes = 0
        global analisis_empresa_dict, analisis_por_fecha
        analisis_empresa_dict = {}
        analisis_por_fecha = {}

        for mensaje in xml_raiz.findall('.//mensaje'):
            total_mensajes += 1
            texto_mensaje = normalizar_texto(mensaje.text)
            
            fecha_encontrada = re.search(r"\d{2}/\d{2}/\d{4}", mensaje.text)
            if fecha_encontrada:
                fecha_mensaje = fecha_encontrada.group()
            else:
                continue

            sentimiento_mensaje = clasificar_sentimiento(texto_mensaje, palabras_positivas, palabras_negativas)

            if fecha_mensaje not in analisis_por_fecha:
                analisis_por_fecha[fecha_mensaje] = {'positivos': 0, 'negativos': 0, 'neutros': 0, 'total': 0}
            analisis_por_fecha[fecha_mensaje]['total'] += 1
            if sentimiento_mensaje == 'positivo':
                analisis_por_fecha[fecha_mensaje]['positivos'] += 1
            elif sentimiento_mensaje == 'negativo':
                analisis_por_fecha[fecha_mensaje]['negativos'] += 1
            else:
                analisis_por_fecha[fecha_mensaje]['neutros'] += 1

            for empresa in nodo_empresas.findall('empresa'):
                nombre_empresa = normalizar_texto(empresa.find('nombre').text)
                if nombre_empresa not in analisis_empresa_dict:
                    analisis_empresa_dict[nombre_empresa] = AnalisisEmpresa(nombre_empresa)

                analisis_empresa_dict[nombre_empresa].analisis_general.aumentar_sentimiento(sentimiento_mensaje)

                servicios = empresa.find('servicios')
                if servicios is not None:
                    for servicio in servicios.findall('servicio'):
                        nombre_servicio = normalizar_texto(servicio.get('nombre'))
                        alias_servicio = [normalizar_texto(alias.text) for alias in servicio.findall('alias')]

                        if nombre_servicio in texto_mensaje or any(alias in texto_mensaje for alias in alias_servicio):
                            analisis_empresa_dict[nombre_empresa].aumentar_servicio(nombre_servicio, sentimiento_mensaje)

        respuesta_xml = generar_respuesta_xml(total_mensajes, analisis_empresa_dict, analisis_por_fecha)

        archivo_salida = os.path.join('archivos', 'salida.xml')
        if os.path.exists(archivo_salida):
            xml_existente = XML.parse(archivo_salida)
            xml_raiz_existente = xml_existente.getroot()
            nueva_respuesta = XML.fromstring(respuesta_xml)
            xml_raiz_existente.append(nueva_respuesta.find('respuesta'))
            xml_string = XML.tostring(xml_raiz_existente, encoding='unicode')
        else:
            xml_string = respuesta_xml

        with open(archivo_salida, 'w', encoding='utf-8') as salida:
            salida.write(xml_string)

        return jsonify({'contenido_archivo': xml_string, 'archivo_salida': archivo_salida})

    except XML.ParseError as e:
        return jsonify({'error': f"Error de análisis de XML: {str(e)}"}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def clasificar_sentimiento(texto, lista_positivos, lista_negativos):
    positivos_detectados = len([palabra for palabra in lista_positivos if palabra in texto])
    negativos_detectados = len([palabra for palabra in lista_negativos if palabra in texto])

    if positivos_detectados > negativos_detectados:
        return 'positivo'
    elif negativos_detectados > positivos_detectados:
        return 'negativo'
    else:
        return 'neutro'

def generar_respuesta_xml(total_mensajes, analisis_empresa_dict, analisis_por_fecha):
    raiz_respuesta = XML.Element("lista_respuestas")

    for fecha, conteo_mensajes in analisis_por_fecha.items():
        nodo_respuesta = XML.SubElement(raiz_respuesta, "respuesta")
        XML.SubElement(nodo_respuesta, "fecha").text = fecha

        nodo_mensajes = XML.SubElement(nodo_respuesta, "mensajes")
        XML.SubElement(nodo_mensajes, "total").text = str(conteo_mensajes["total"])
        XML.SubElement(nodo_mensajes, "positivos").text = str(conteo_mensajes["positivos"])
        XML.SubElement(nodo_mensajes, "negativos").text = str(conteo_mensajes["negativos"])
        XML.SubElement(nodo_mensajes, "neutros").text = str(conteo_mensajes["neutros"])

        nodo_analisis = XML.SubElement(nodo_respuesta, "analisis")
        for empresa in analisis_empresa_dict.values():
            nodo_empresa = XML.SubElement(nodo_analisis, "empresa", nombre=empresa.nombre_empresa)
            
            nodo_mensajes_empresa = XML.SubElement(nodo_empresa, "mensajes")
            XML.SubElement(nodo_mensajes_empresa, "total").text = str(empresa.analisis_general.total_mensajes)
            XML.SubElement(nodo_mensajes_empresa, "positivos").text = str(empresa.analisis_general.positivos_mensajes)
            XML.SubElement(nodo_mensajes_empresa, "negativos").text = str(empresa.analisis_general.negativos_mensajes)
            XML.SubElement(nodo_mensajes_empresa, "neutros").text = str(empresa.analisis_general.neutros_mensajes)

            nodo_servicios = XML.SubElement(nodo_empresa, "servicios")
            for servicio, conteo_servicio in empresa.servicios_empresa.items():
                nodo_servicio = XML.SubElement(nodo_servicios, "servicio", nombre=servicio)
                
                nodo_mensajes_servicio = XML.SubElement(nodo_servicio, "mensajes")
                XML.SubElement(nodo_mensajes_servicio, "total").text = str(conteo_servicio.total_mensajes)
                XML.SubElement(nodo_mensajes_servicio, "positivos").text = str(conteo_servicio.positivos_mensajes)
                XML.SubElement(nodo_mensajes_servicio, "negativos").text = str(conteo_servicio.negativos_mensajes)
                XML.SubElement(nodo_mensajes_servicio, "neutros").text = str(conteo_servicio.neutros_mensajes)

    string_salida = XML.tostring(raiz_respuesta, encoding="unicode")
    xml_parseado = minidom.parseString(string_salida)
    return xml_parseado.toprettyxml(indent="  ")

def obtener_datos_mensajes():
    archivo_xml = 'archivos/salida.xml'
    
    arbol_xml = XML.parse(archivo_xml)
    raiz_xml = arbol_xml.getroot()

    lista_datos_mensajes = []
    for nodo_respuesta in raiz_xml.findall('respuesta'):
        fecha = nodo_respuesta.find('fecha').text.strip()
        total_mensajes = int(nodo_respuesta.find('mensajes/total').text)
        positivos_mensajes = int(nodo_respuesta.find('mensajes/positivos').text)
        negativos_mensajes = int(nodo_respuesta.find('mensajes/negativos').text)
        neutros_mensajes = int(nodo_respuesta.find('mensajes/neutros').text)

        lista_empresas = []
        for empresa in nodo_respuesta.find('analisis').findall('empresa'):
            nombre_empresa = empresa.get('nombre').strip()
            total_empresa = int(empresa.find('mensajes/total').text)
            positivos_empresa = int(empresa.find('mensajes/positivos').text)
            negativos_empresa = int(empresa.find('mensajes/negativos').text)
            neutros_empresa = int(empresa.find('mensajes/neutros').text)

            lista_empresas.append({
                'nombre': nombre_empresa,
                'total': total_empresa,
                'positivos': positivos_empresa,
                'negativos': negativos_empresa,
                'neutros': neutros_empresa,
            })

        lista_datos_mensajes.append({
            'fecha': fecha,
            'total': total_mensajes,
            'positivos': positivos_mensajes,
            'negativos': negativos_mensajes,
            'neutros': neutros_mensajes,
            'empresas': lista_empresas,
        })
    
    return lista_datos_mensajes

@aplicacion.route('/rango_resumen', methods=['GET'])
def rango_resumen():
    fecha_inicio = request.args.get('fecha_inicio')
    fecha_fin = request.args.get('fecha_fin')

    # Convertir las fechas a objetos datetime para la comparación
    from datetime import datetime
    fecha_inicio_dt = datetime.strptime(fecha_inicio, '%Y-%m-%d')
    fecha_fin_dt = datetime.strptime(fecha_fin, '%Y-%m-%d')

    datos_rango = [
        dato for dato in obtener_datos_mensajes()
        if fecha_inicio_dt <= datetime.strptime(dato['fecha'], '%d/%m/%Y') <= fecha_fin_dt
    ]

    return jsonify(datos_rango)
    

if __name__ == '__main__':
    aplicacion.run(debug=True)